﻿using System;


namespace _14.CuretDateAndTime
{
    class CurentDateAndTime
    {
        static void Main()
        {
            Console.WriteLine("The date and time now is {0}",DateTime.Now);
        }
    }
}
