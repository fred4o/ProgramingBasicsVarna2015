﻿using System;

namespace _07.PrintFirstAndLastNamen
{
    class PrintAndLastName
    {
        /*
        Problem 7.	Print First and Last Name
        Create console application that prints your first and last name, each at a separate line.
        */
        static void Main()
        {
            Console.WriteLine("Milen\nPavlov");
           
        }
    }
}
