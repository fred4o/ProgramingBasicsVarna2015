﻿using System;

namespace _14.CurentDateAndTime
{
    class CurentDateAndTime
    {
        /*
        Problem 14.	* Current Date and Time
        Create a console application that prints the current date and time. Find in Internet how.
        */
        static void Main()
        {
            DateTime getDateTime = DateTime.Now;
            Console.WriteLine(getDateTime);

        }
    }
}
