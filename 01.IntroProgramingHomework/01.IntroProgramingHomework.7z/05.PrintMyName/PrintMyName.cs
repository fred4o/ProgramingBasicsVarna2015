﻿using System;

namespace _05.PrintMyName
{
    class PrintMyName
    {
        /* 
        Problem 5.	Print Your Name
        Modify the previous application to print your name. Ensure you have named the application well (e.g. “PrintMyName”). 
        You should submit a separate project Visual Studio project holding the PrintMyName class as part of your homework. 
        */

        static void Main()
        {

            Console.WriteLine("Hello Milen Pavlov");
        }
    }
}
