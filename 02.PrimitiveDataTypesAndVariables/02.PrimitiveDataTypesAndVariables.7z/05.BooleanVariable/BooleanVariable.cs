﻿using System;


namespace _05.BooleanVariable
{
    class BooleanVariable
    {
        /* 
        Problem 5.	Boolean Variable
        Declare a Boolean variable called isFemale and assign an appropriate value corresponding to your gender.
        Print it on the console.	
        */

        static void Main()
        {
            bool isFemale;
            isFemale = false;
            Console.WriteLine("Am I female? \n {0}",isFemale);
        }
    }
}
